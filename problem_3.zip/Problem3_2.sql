-- Update the address for the entire family
UPDATE address
SET address = '123 New Street'
WHERE address_id = 1;


